"""Reproduce a source-identity / controller-log audit, NOT a policy efficacy study.

Requires numpy and scipy. Does not execute downloaded code, fit a model, infer
unmeasured outcomes, or certify physical execution/QC/costs. Third-party MAT
files are downloaded only with --download and are not part of the deliverable.
"""
from __future__ import annotations

import argparse
from collections import Counter
import csv
import gzip
import hashlib
import json
from pathlib import Path
import sys
import urllib.request

import numpy as np
import scipy
from scipy.io import loadmat

REVISION = "ea26553465cac600f14cbc109b83c9a42da15e39"
BASE = f"https://raw.githubusercontent.com/dibbelab/Cycloop/{REVISION}/Computational_Analysis/Cycling/Output_data/"
SOURCES = {
    "FIG4_fghij_RefOsc_I.mat": (23317052, "f874bc2ba4be79483fdb8761c94edb0a9f4de573"),
    "FIG4_pqrst_RefOscG.mat": (14528635, "7e04d9e488da7a9cb56b6a952a7767252984abb3"),
    "SFIG8_abcde_RefOsc_II.mat": (19998121, "933c547b9c4fa600108041ecd2f2b5ef540d4c51"),
    "SFIG8_fghij_RefOsc_III.mat": (18307415, "b4734c33e1b10c5bd4d9c498846ec55daa313aed"),
}


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path: Path, data) -> None:
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def vector(value) -> np.ndarray:
    return np.asarray(value).reshape(-1)


def audit_mat(path: Path, name: str):
    raw = path.read_bytes()
    size, expected_blob = SOURCES[name]
    blob = hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()
    if len(raw) != size or blob != expected_blob:
        raise ValueError(f"Pinned source identity mismatch: {name}")
    data = loadmat(path, squeeze_me=True, struct_as_record=False)
    phases, actions = vector(data["PhaseMAT"]), vector(data["inputLEVELS"])
    init = int(data["initTP"])
    if not np.isin(actions, [0, 1]).all() or len(phases) != len(actions):
        raise ValueError("Unexpected action/phase axis")
    tracked, removed = vector(data["trackedCELLS"]), vector(data["removedCELLS"])
    objects = list(tracked) + list(removed)
    labels = [int(obj.LABEL) for obj in objects]
    if len(set(labels)) != len(labels):
        raise ValueError("Duplicate native LABEL; cannot silently join")
    lookup = {int(obj.LABEL): obj for obj in objects}
    counts = Counter()
    rows = []
    for index, packet in enumerate(phases):
        frame = index + 1  # MATLAB's 1-based frame, not the Python offset.
        row = {"source_file": name, "frame_1based": frame, "recorded_action": int(actions[index]),
               "hardware_execution": "unknown", "qc": "unknown", "cost": None}
        if index < init:
            row["record_type"] = "calibration_not_controller_replay"
            counts["calibration_frames"] += 1
            rows.append(row)
            continue
        theta, refs = vector(packet.stimaf).astype(float), vector(packet.Theta_r).astype(float)
        used_labels = vector(packet.trackedCELLS).astype(int)
        if len(theta) != len(used_labels) or not np.isfinite(theta).all():
            raise ValueError("Invalid predecision phase/label packet")
        counts["phase_label_mentions_all_postcalibration"] += len(used_labels)
        for label in used_labels:
            if int(label) not in lookup:
                counts["unresolved_native_label_mentions"] += 1
                continue
            obj = lookup[int(label)]
            frames, fluo = vector(obj.frame).astype(int), vector(obj.MaxGreenFluo).astype(float)
            if len(frames) != len(fluo):
                raise ValueError("Unequal native frame/fluorescence lengths")
            if not np.any(frames < frame):
                counts["label_mentions_without_past_frame"] += 1
            if not np.any(frames == frame - 1):
                counts["label_mentions_without_immediate_previous_frame"] += 1
            at_response = np.flatnonzero(frames == frame)
            if len(at_response) > 1:
                raise ValueError("Duplicate native frame")
            # Availability diagnostic only. Values are never scored as utility.
            if len(at_response) and np.isfinite(fluo[at_response[0]]):
                counts["label_mentions_with_finite_same_label_next_observation"] += 1
            else:
                counts["label_mentions_without_finite_same_label_next_observation"] += 1
        if len(refs) != 1 or not np.isfinite(refs[0]):
            row["record_type"] = "reference_missing_or_nonfeedback_phase"
            counts["reference_missing_or_nonfeedback_frames"] += 1
            rows.append(row)
            continue
        before = 0.0 if index == init else float(packet_scalar(phases[index - 1].Theta_r))
        if not np.isfinite(before):
            row["record_type"] = "unreplayable_missing_prior_reference"
            counts["unreplayable_missing_prior_reference"] += 1
            rows.append(row)
            continue
        # ctrlRefOsc chooses u before integrating and storing the NEW Theta_r.
        # Initial zero is protocol evidence (main_run_exp.m), not a logged timestamp.
        score = float(np.sum(np.sin(theta - before) * (theta < .4 * 2 * np.pi)))
        if not np.isfinite(score):
            raise ValueError("Nonfinite decision score")
        reconstructed = int(score < 0)
        wrong_score = float(np.sum(np.sin(theta - refs[0]) * (theta < .4 * 2 * np.pi)))
        match = reconstructed == int(actions[index])
        counts["replayed_frames"] += 1
        counts["action_matches"] += int(match)
        counts["action_mismatches"] += int(not match)
        counts["wrong_same_row_reference_mismatches"] += int(int(wrong_score < 0) != int(actions[index]))
        counts["exact_zero_scores"] += int(score == 0)
        row.update(record_type="finite_reference_controller_replay", phase_count=len(theta),
                   theta_reference_before=before, theta_reference_after=float(refs[0]),
                   decision_score=score, reconstructed_action=reconstructed, action_match=match,
                   state_frame_upper_bound=frame - 1,
                   state_identity_status="native_phase_log_and_labels; raw_image_feature_equivalence_not_certified")
        rows.append(row)
    summary = {
        "file": name, "url": BASE + name, "bytes": len(raw), "git_blob_sha1": blob,
        "sha256": hashlib.sha256(raw).hexdigest(), "source_identity_verified": True,
        "frames": len(actions), "initTP": init, "sampling_interval_minutes_setting": int(data["smplngTM"]),
        "native_tracked_objects_at_end": len(tracked), "native_removed_objects": len(removed),
        "unique_native_labels": len(labels), "counts": dict(counts),
        "postcalibration_action_counts": {str(a): int(np.sum(actions[init:] == a)) for a in [0, 1]},
        "independent_culture_verified": False, "effect_estimated": False,
    }
    return summary, rows


def packet_scalar(value):
    values = vector(value)
    if len(values) != 1:
        raise ValueError("Prior reference is not a scalar")
    return values[0]


def audit_existing_relations(root: Path):
    directory = root / "tools/datasets/audit_results/20261001_state_search_build_v4"
    expected = json.loads((directory / "outputs_sha256.json").read_text())
    hashes = {name: sha256(directory / name) == digest for name, digest in expected.items()}
    if not all(hashes.values()):
        raise ValueError("Published relation output checksum mismatch")
    tables = {}
    for name in ["questions", "actions", "attempts", "state_samples", "response_samples"]:
        with gzip.open(directory / (name + ".jsonl.gz"), "rt") as stream:
            tables[name] = [json.loads(line) for line in stream]
    attempts = tables["attempts"]
    states = {s["state_sample_id"]: s for s in tables["state_samples"]}
    responses = {r["response_sample_id"]: r for r in tables["response_samples"]}
    aligned = sum(states[r["state_sample_id"]]["state_index"] + 1 == r["action_index"]
                  == responses[r["response_sample_id"]]["response_index"] for r in attempts)
    raw_directory = root / "tools/datasets/audit_results/20261001_state_search/records"
    with (raw_directory / "gross_hc007.raw").open() as stream:
        gross = list(csv.DictReader(stream))
    with (raw_directory / "idr_annotation.raw").open() as stream:
        annotation = list(csv.DictReader(stream))
    controls = sorted({r["well"] for r in gross if r["Drug1"] == "Untreated"})
    times = sorted({float(r["elapsed_minutes"]) for r in gross})
    relevant_wells = set(controls) | {"B1", "C1"}
    annotation_rows = [{key: row[key] for key in ["Plate", "Well", "Compound 1 Name", "Compound 1 Concentration (microMolar)"]}
                       for row in annotation if row["Plate"] == "HC00701" and row["Well"] in relevant_wells]
    return {
        "table_counts": {key: len(value) for key, value in tables.items()},
        "all_declared_output_hashes_match": all(hashes.values()), "hashes_checked": len(hashes),
        "j_to_j_plus_1_aligned_attempts": aligned,
        "unknown_qc_attempts": sum(r["qc_status"] == "unknown" for r in attempts),
        "unconfirmed_execution_attempts": sum(r["actually_executed"] is None for r in attempts),
        "unknown_cost_attempts": sum(r["cost"] is None for r in attempts),
        "outcomes_with_no_exported_value": sum(r["outcome_value"] is None for r in tables["response_samples"]),
        "action_counts": dict(Counter(r["action_id"] for r in attempts)),
        "source_archive_redownloaded": False,
        "scope": "fresh audit of published derived relations; not a fresh raw DCC archive audit",
        "gross_hcc1143_check": {
            "raw_file_sha256": sha256(raw_directory / "gross_hc007.raw"),
            "annotation_sha256": sha256(raw_directory / "idr_annotation.raw"),
            "rows": len(gross), "earliest_elapsed_minutes": min(times),
            "observed_time_intervals_minutes": sorted({b - a for a, b in zip(times, times[1:])}),
            "untreated_wells_from_raw": controls, "annotation_crosscheck": annotation_rows,
            "review_text_error": "state_search_review_20261001.json names A1 B1 C1; raw/annotation/inventory identify A1 A3 A5",
            "eligibility_change": False,
        },
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--raw-dir", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--llm-root", type=Path)
    parser.add_argument("--download", action="store_true")
    args = parser.parse_args()
    args.raw_dir.mkdir(parents=True, exist_ok=True)
    args.out.mkdir(parents=True, exist_ok=False)
    summaries, rows = [], []
    for name, (size, _) in SOURCES.items():
        path = args.raw_dir / name
        if not path.exists():
            if not args.download:
                raise FileNotFoundError(f"{path}: provide the pinned file or use --download")
            with urllib.request.urlopen(BASE + name, timeout=45) as response:
                raw = response.read(size + 1)
            if len(raw) != size:
                raise ValueError(f"Unexpected download size: {name}")
            path.write_bytes(raw)
        summary, records = audit_mat(path, name)
        summaries.append(summary)
        rows.extend(records)
    totals = Counter()
    for summary in summaries:
        totals.update(summary["counts"])
    payload = {
        "scope": "artifact identity + native-label linkage + deterministic controller command reconstruction",
        "not_certified": ["raw image to exact online feature equality", "runtime code identity",
                          "hardware execution", "full enrollment and failure denominator", "QC", "costs",
                          "independent physical batches", "alternative policy outcome", "STATE input compatibility"],
        "python": sys.version.split()[0], "numpy": np.__version__, "scipy": scipy.__version__,
        "cycloop_revision": REVISION, "datasets": summaries, "totals": dict(totals),
        "scientific_classification": "online_log_partially_recovered; efficacy_gate_remains_closed",
        "state_gain": None, "efficacy_run": False, "model_forward_calls": 0,
    }
    if args.llm_root:
        payload["llm_derived_relations"] = audit_existing_relations(args.llm_root)
    save(args.out / "audit_results.json", payload)
    with (args.out / "decision_log_reconstruction.jsonl").open("w", encoding="utf-8") as stream:
        for row in rows:
            stream.write(json.dumps(row, ensure_ascii=False, allow_nan=False) + "\n")
    save(args.out / "output_hashes.json", {p.name: sha256(p) for p in sorted(args.out.iterdir()) if p.is_file()})
    print(json.dumps({"totals": dict(totals), "state_gain": None, "efficacy_run": False}))


if __name__ == "__main__":
    main()
