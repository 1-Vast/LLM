STATE decision-state evidence research, 2026-10-01

Read STATE_evidence_research_20261001.html for the Chinese research report.

Files
  audit_state_evidence.py: original independent audit, not an efficacy estimator.
  audit_results.json: source identity, log replay, native-label and repository checks.
  decision_log_reconstruction.jsonl: 2,000 source-frame records; calibration and
    nonfeedback/missing-reference records remain explicit.
  review_addendum.json: new evidence and the HCC1143 control-well correction;
    no existing scientific gate is overridden.
  source_manifest.json: fixed source revisions and file digests.
  regression_tests.xml / verification.json: 64 passed, 1 skipped; no model call.
  SHA256SUMS.json: integrity manifest for this deliverable (excludes itself).

Reproduce the Cycloop audit
  python -m pip install numpy==2.3.5 scipy==1.17.0
  python audit_state_evidence.py --raw-dir raw --out audit_new --download

Also inspect the published LLM relations
  Check out 1-Vast/LLM at e283beb97676c2c0d520bd092ba0100bfe412eb0 and add:
  --llm-root /path/to/LLM

The output directory must not already exist. The script downloads about 76 MB
from fixed public raw GitHub URLs only when --download is supplied and the
corresponding files are missing. It validates exact sizes and pinned Git blob
hashes before parsing. Downloaded files are not executed.

The original third-party MAT files and author source code are not redistributed
in this package. Dataset/code licensing and downstream reuse permissions must
be assessed separately from article licenses.

Limits
  Action reconstruction is a deterministic log consistency check. It does not
  certify original runtime code, original-image-to-feature equality, physical
  actuation, independent culture batches, complete QC/costs or causal efficacy.
  Preserved online labels identify tracking objects, not necessarily unique
  biological cells. Same-label next-frame availability is not an assay success.
  No STATE weights were loaded; no effect, missing outcome or cost was imputed.
  The optional original DCC bulk archive test was skipped; the published derived
  relations and available source receipts were checked.
  No GitHub write or contact with researchers was performed.
