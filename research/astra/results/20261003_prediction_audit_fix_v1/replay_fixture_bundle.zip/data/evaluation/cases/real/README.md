> **File summary**
> - **Path**: `data/evaluation/cases/real/README.md`
> - **Purpose**: Boundary document for the real-data mechanism-contrast case package.
> - **Core points**: cases are built from checksum-verified public releases; the oracle licenses decisions from evidence, it is not biological ground truth; the public package contains no archetype, split, or answer.
> - **Interfaces / data**: `maestro-build-cases`; `cases/real/public/*.json`; `cases/real/private/*.results.json`; `data/evaluation/derived/real_case_manifest.json`.
> - **Depends on**: `data/evaluation/README.md`, `src/evaluation/case_builder.py`, `src/evaluation/evidence_base.py`.

# Real-Data Mechanism-Contrast Cases

> **Status: frozen development and regression data (2026-09-12).**
> This package was inspected and debugged against repeatedly, and it carries three
> construction defects that were corrected only afterwards: BRAF and EGFR appear in
> both splits because the split was assigned inside each archetype rather than
> globally; the offered comparator was ranked by the response an agent is meant to
> acquire; and the RNA abundance action was typed as a protein measurement. Do not
> use it for a generalisation claim. The corrected package built by the same tool is
> at `data/evaluation/cases/real_v2/`, with manifest
> `data/evaluation/derived/real_case_manifest_v2.json`; the corrections and their
> code locations are recorded in the
> [2026-09-12 day record](D:/MAESTRO/log/20260912/README.md).

This package is generated, not hand-written. `maestro-build-cases` reads the local
DepMap 24Q2 and PRISM Repurposing 19Q4 releases, refuses any release whose recorded
checksum did not verify, classifies each `(model, gene, compound)` triple against a
frozen set of joint evidence patterns, and writes a public case, an evaluator-only
result file, and an evaluator-only manifest entry.

Rebuild it with:

```text
maestro-build-cases --per-archetype 10 --per-gene 6 --overwrite
```

## What each record is

Every value in every case is a real published record. The public premise holds a
processed CRISPR gene-effect score and the index compound's fitted PRISM
dose-response curve for the same model. Each menu action returns another existing
record: RNA abundance for the annotated target in that model, the fitted curve of a
second registered compound against the same target, the same compound in a model that
does not score the gene as a dependency, or a panel-wide summary of how many models
score the gene as a dependency. `matched_target_engagement` is registered and
permanently unavailable, because no condition-matched engagement or residual-activity
measurement exists anywhere in these releases. That unavailability is what makes an
informed deferral a legitimate terminal answer in some cases.

No action commissions a new experiment, and no record is a new measurement. The panel
summary is a `derived_analysis` over already-processed scores, so it can constrain how
existing measurements are read but can never satisfy a biological premise.

## What the oracle is, and what it is not

The private files hold **evidence-licensing rules**, not biological truth. A rule
states that a named development action is supported by a specific revealed
observation in this context, and carries the reasoning in its `note`. Licensing is
deliberately conservative: a rule resting on a measurement also requires that
measurement to have passed its declared quality check.

A licensing rule is a pre-registered convention about what the evidence supports. It
is not a claim that the mechanism is established, that the compound engages the
target, or that a different laboratory would reach the same conclusion. A policy may
disagree with the convention on scientific grounds; the evaluation records that as a
disagreement with a declared standard, and the case's public declarations state
exactly what each action is expected to show under each explanation, so the standard
is visible to every policy before it acts.

## Leakage boundary

The public file contains the premise, the two registered explanations, the costed
action menu with its declared observation-to-explanation mapping, and the case's
limitations. It does not contain the archetype, the split, the critical actions, the
licensing rules, or any measured value behind a menu action. Those live in the
private result files and in `data/evaluation/derived/real_case_manifest.json`, which
is evaluator-owned. `tests/test_directed_repair_and_licensing.py` asserts that the
public files carry none of them.

Cases are split by target gene, so no gene appears in both `development` and `test`.
The manifest records each case's `source_cluster` (its gene) so that repeated cases
on one target are not counted as independent evidence about a policy.

## Declared construction settings

The thresholds in `data/evaluation/derived/real_case_manifest.json` under
`construction_settings` were frozen before any policy ran. They are selection
settings that decide which joint evidence pattern a case represents. None of them is
a validated biological cut-off, and the cases say so in their own limitations.

## What this package cannot support

It cannot establish target engagement, mechanism, or clinical relevance. CRISPR and
PRISM records are not matched for perturbation method, dose, exposure duration,
assay, or replicate structure, and a single-target annotation in release metadata is
not evidence of pharmacological selectivity. Each case repeats these limits in its
own file so that a policy reading only the case still sees them.
