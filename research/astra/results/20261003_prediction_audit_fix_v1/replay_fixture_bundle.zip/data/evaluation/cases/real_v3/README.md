> **File summary**
> - **Path**: `data/evaluation/cases/real_v3/README.md`
> - **Purpose**: Boundary document for the typed-premise real-data mechanism-contrast case package.
> - **Core points**: every prerequisite field declares the quantity, entity, units and context that must back it; admission compares a measurement against that declaration rather than comparing two strings; case selection, splits and outcomes are unchanged from `real_v2`.
> - **Interfaces / data**: `maestro-build-cases`; `cases/real_v3/public/*.json`; `cases/real_v3/private/*.results.json`; `data/evaluation/derived/real_case_manifest_v3.json`.
> - **Depends on**: `src/evaluation/case_builder.py`, `src/evaluation/feasibility.py`, `data/evaluation/cases/real_v2/README.md`.

# Typed-premise real-data mechanism-contrast cases

This package is `real_v2` with one addition: every interpretation field a case
uses as a prerequisite carries a **declared meaning**. `real_v2` remains as it
was and is not superseded as evidence; it is the comparison point that shows
what the typing changes.

Rebuild it with:

```text
maestro-build-cases --public-cases data/evaluation/cases/real_v3/public --private-results data/evaluation/cases/real_v3/private --manifest data/evaluation/derived/real_case_manifest_v3.json --overwrite
```

## What changed

A prerequisite used to be a string. An action declared `supplies:
["abundance:target_rna"]`, another declared `prerequisites:
["abundance:target_rna"]`, and admission compared the two names. Nothing in that
comparison referred to what was measured, so a record could discharge a premise
its assay could not address as long as the field was named suitably.

Each case now carries a `premise_registry` entry per prerequisite field:

```json
"premise_registry": {
  "abundance:target_rna": {
    "quantity": "rna_abundance",
    "entity": "ALK",
    "units": "log2_tpm_plus_1",
    "context_identifier": "ACH-000804:NB1",
    "require_direct_measurement": true
  }
}
```

Admission now checks the supplying **action's** declared quantity, entity, site
and units, together with the **record's** context, time and quality, against
that requirement. A bridge estimate is refused where a direct measurement is
required, and a record from another context is refused where the field is
context-bound.

The requirement names RNA abundance because RNA abundance is what the release
contains. Naming protein abundance would have been the stronger and more
desirable premise, and every case would then be unsolvable; naming protein
abundance while accepting an RNA record is the substitution the registry exists
to prevent.

## What this package contains

58 cases over 40 target genes and 45 DepMap models, split 31 development and 27
test with an empty gene intersection — identical to `real_v2`, because typing
the premises changed no case's selection, outcome, or licensing rule. 27 cases
register the RNA prerequisite. Zero fields are untyped; `PublicCase.untyped_premises()`
returns empty for all 58.

## What the typing is measured to do

Measured on both real packages by `log/20260913`'s framework probes (recorded in the [2026-09-13 day record](../../../../log/20260913/README.md)):

- 27 of 27 cases with a prerequisite have it discharged by the correctly typed supplier.
- Retyping only that supplier, changing no name and no record, blocks the dependent action in 27 of 27, with `quantity_mismatch` as the reason.

## What it is not

The licensing rules remain an **evidence-sufficiency convention** declared before
any policy ran, not biological ground truth, and a policy may legitimately
disagree with them. No record here is a condition-matched target-engagement or
residual-activity measurement.

The known limitation of `real_v2` is unchanged and still governs: every action
supplies one field at unit cost against a two-unit budget, so a check-and-repair
loop and a reactive outcome-aware selector provably choose the same bundle. This
package **cannot discriminate between them** either. Typing the premises makes
admission honest; it does not make the action grammar richer.
