> **File summary**
> - **Path**: `data/evaluation/preregistrations/20260914_blind_adjudication.md`
> - **Purpose**: pre-registration of the MAESTRO blind-adjudication protocol and of the four
>   section 37 rows that have never run, fixed before any adjudication exists and before any of
>   the four arms is executed.
> - **Core points**: two adjudicators are fixed and hashed before any arm output is compared to
>   them; the four missing rows get named arms or stay `not_run` with a reason; paid calls are
>   priced against a declared ceiling and reported separately from laboratory cost.
> - **Interfaces / data**: `src/evaluation/score_table.py`, `src/evaluation/provider_spend.py`,
>   `data/evaluation/cases/real_v3/`, `data/evaluation/cases/engagement_v1/`.
> - **Depends on**: `20260914_evaluation_protocol.md`, `20260914_engagement_package.md`,
>   `log/20260914/README.md`.

# Pre-registration: blind adjudication and the four missing rows (2026-09-14, night)

Written before any adjudication packet was produced, before any of the four arms ran, and
before any agreement statistic existed. Times are UTC.

## 1. Why

The section 37 table produced on 2026-09-14 reports `evidence_for_core_claim = false` for two
reasons that are both about protocol rather than about the system: four of its six rows have no
arm, and no adjudication was blind to the arms' outputs. Until both are fixed, no comparison in
this repository may be quoted as evidence, however the numbers fall.

## 2. What is already known, and therefore disclosed

- The three offline rows that have run (`fixed_expert`, `maestro_core` and the prediction-input
  panel) are recorded in `log/20260914/README.md`; their counts are known to the author of this
  pre-registration.
- The engagement package's six cases, their hidden engagement records and the decisions six
  offline arms reached on them are known to the author (same record). The adjudication below is
  therefore **not** blind on the author's side; it is blind on the adjudicators' side, which is
  what the standard requires of an adjudicator and is the weaker of the two claims. This
  limitation is reported with every agreement statistic.
- No LLM arm has been run on either package in this session. The provider was probed twice for
  reachability at a total priced cost of about USD 0.0011.

## 3. Paid-call discipline

Rates are the recorded campaign rates, verified 2026-09-12 against the provider's published
pricing: USD 0.30 per million cache-miss input tokens, USD 0.006 per million cache-hit input
tokens, USD 1.20 per million output tokens. The authorised ceiling is **USD 5.00**. The
conservative carry-in is **USD 0.694763**: 0.590786 recorded in the 2026-09-13 day record, plus
0.058555 for an LLM arm that was never written back to the campaign ledger, plus 0.045422
recorded only in a concurrent session's notes. Remaining budget is therefore about **USD 4.305**.

Every call is reserved before it is made and charged after it returns, priced from the
provider's own usage fields, and written to a run-local ledger
(`src/evaluation/provider_spend.py`). A call that fails after the provider processed tokens is
charged at its reservation, never at zero. Exceeding the ceiling is refused by name. Provider
spend is reported separately and never enters a cost comparison, which stays in wells and
turnaround days.

The model spends several hundred completion tokens reasoning before it emits an object, so every
arm budgets at least 1,200 completion tokens per call; a truncated reply is recorded as a
provider failure rather than scored as a wrong answer.

## 4. The four rows and the arms that will fill them

The table's rows are fixed and are not renamed. Each row below names the arm that will stand for
it, on `real_v3` (58 cases, 40 target clusters), which is the package rows 1 and 5 already ran on.

| Row | Arm | What it is |
|---|---|---|
| `simple_model_plus_voi` | `simple_model_voi` | A response model fitted on the **development split only** - one logistic model per action outcome over public premise features - plus exact value-of-information selection over the declared menu, and the licensing-rule decision. No LLM. |
| `retrieval_single_agent` | `ordinary_llm` | The existing single-agent arm: the same menu, the same result-access boundary, one model call per acquisition step and one for the decision. |
| `same_llm_explicit_hypotheses` | `explicit_hypotheses_llm` | The same model, required to maintain an explicit posterior over the two registered explanations and to select the action it says maximises the value of information, then decide. The difference from the row above is the enforced hypothesis bookkeeping, nothing else. |
| `full_system_shuffled_predictions` | `maestro_core_shuffled_predictions` | The full system with the prediction input it reads replaced by a seeded derangement over the same action set, so a gain that survives the shuffle did not come from the prediction. |

An arm that cannot be run, or whose provider fails on more than a quarter of its cases, leaves
its row `not_run` with that reason. No arm is assigned to a row merely because it exists.

## 5. The blind adjudication

Two adjudicators, both fixed and hashed **before** any arm output is compared to them:

1. **The mechanical adjudicator** is the licensing rule set already frozen in each package's
   evaluator-only files. Its digest is recorded per case in the run payload.
2. **The independent reviewer** is the configured model in a fresh context, given an
   adjudication packet and nothing else. The packet contains the case premise, the registered
   explanations and their development actions, every hidden record the case holds (including the
   engagement records and the always-hidden partition where one exists), and the menu's
   declarations. It contains **no arm output, no policy name, no licensing rule and no
   decision**. The reviewer returns the set of development actions the evidence supports, the
   minimum evidence it rests on, and the actions it rules out.

The packets and the reviewer's verdicts are written to a run directory and hashed before any
comparison is computed. Agreement is then reported as: raw agreement on the licensed set,
Cohen's kappa over the decision labels, and the per-case disagreement list with both verdicts
quoted. A case where the two adjudicators disagree is **disputed**: it is reported separately and
is never merged into a headline rate.

The reviewer shares a model family with two of the four arms. That is a stated weakness of this
protocol, not a hidden one: agreement between the reviewer and an LLM arm is reported beside
agreement between the reviewer and the offline arms, so a shared-model effect is visible rather
than assumed absent.

## 6. Metrics

Unchanged from the protocol pre-registration: wrong development action split into wrong advance,
premature abandonment and wrong direction; over-deferral and appropriate deferral counted
separately; Wilson intervals at case level and a seeded cluster bootstrap over the target gene;
cost in wells and turnaround days only. Two additional columns are reported for every row:
agreement with the independent reviewer, and the number of disputed cases excluded from the
headline rate.

`conclusion.evidence_for_core_claim` stays false unless every row ran **and** the adjudication is
blind. Running the four rows does not by itself make it true.

## 7. Pre-registered expectations

- **B1** At least one of the four rows will fail to run, and the reason will be recorded rather
  than the row dropped.
- **B2** The two LLM rows will show a lower valid-submission rate than the offline rows, and the
  difference will be reported as a protocol property rather than as a decision-quality result.
- **B3** The independent reviewer will disagree with the mechanical adjudicator on at least one
  case of `real_v3`, because the licensing rules are an evidence-sufficiency convention and not
  biological ground truth.
- **B4** The shuffled-prediction row will differ from the full-system row by less than one case
  on `real_v3`, because the arm reads no model prediction on that package; if it differs by more,
  the prediction input is doing something that has not been identified.
- **B5** Total paid spend for this block will stay below USD 1.00, leaving the recorded ceiling
  unbreached.

## 8. What this block cannot establish

An adjudication by a language model is not an independent biological review by a domain expert.
Gate G2's scientific part stays INCONCLUSIVE until a human review is recorded, whatever the
agreement statistics say. Running four more rows does not make the frozen package able to
express a case where a repair changes the decision, and nothing here is a biological result.
