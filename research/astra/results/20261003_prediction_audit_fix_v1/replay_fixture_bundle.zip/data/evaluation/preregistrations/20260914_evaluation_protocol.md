> **File summary**
> - **Path**: `data/evaluation/preregistrations/20260914_evaluation_protocol.md`
> - **Purpose**: pre-registration of the first MAESTRO evaluation-protocol runs, written before either run started.
> - **Core points**:
>   - Two offline runs, fixed arms and fixed definitions; every metric, interval and exit rule is stated here first.
>   - Expectations are written down in advance with their reasons, and what had already been seen is disclosed.
>   - No result of these runs is a biological result, and without blind adjudication none is evidence for the core claim.
> - **Interfaces / data**: `maestro-evaluate --policy protocol --score-table`, `data/evaluation/costing/*.json`, `data/evaluation/derived/real_case_manifest_v3.json`
> - **Depends on**: `src/evaluation/score_table.py`, `src/evaluation/lab_cost.py`, `src/evaluation/prediction_controls.py`

# Pre-registration: MAESTRO evaluation protocol, first runs (2026-09-14)

Written on 2026-09-14 before either run below was started. The command line records this
file's SHA-256 and modification time, and re-hashes it after the run; a later change is a
superseding note appended below, never an edit of this text.

## What is run

| Run id | Cases | Costing overlay | Cluster map |
|---|---|---|---|
| `protocol-real-v3-20260914` | `data/evaluation/cases/real_v3` (58) | `data/evaluation/costing/real_record_retrieval.json` | `real_case_manifest_v3.json`, `source_cluster` |
| `protocol-contract-20260914` | `data/evaluation/cases/public` (2) | `data/evaluation/costing/contract_and_boundary_cases.json` | none (each case is its own cluster) |

Both runs: `--mode decision`, `--maximum-steps 8`, `--policy protocol`, which is exactly
eight offline arms: `fixed_expert`, `prediction_value_heuristic`,
`prediction_value_shuffled`, `prediction_value_removed`, `maestro_core`,
`repair_disabled`, `random_legal_edit`, `outcome_aware_selection`. No provider-backed arm is
run and no paid call is made.

## Definitions, fixed before the run

- **Wrong action**: a verdict of `wrong_advance`, `wrong_abandon` or `wrong_direction`,
  each also reported alone. **Over-deferral** and **no valid decision** (`no_decision`,
  `invalid_submission`) are separate columns.
- **Intervals**: a Wilson 95% interval over cases, and a percentile interval from a cluster
  bootstrap that resamples whole `source_cluster` groups, seed 20260914, 2,000 resamples.
- **Appropriate deferral**: over cases whose reachable decisions contain nothing but
  `defer`, the share where the arm deferred and was scored correct.
- **Cost to reach the evidence standard**: over cases where the arm reached a correct
  non-deferral decision, the declared cost units, wells, turnaround days (sum over executed
  actions) and the count of new measurements and record retrievals. An unpriced action is
  counted as a refusal, never as zero.
- **Prospective hit rate**: `not_registered` for every row, because no arm registers a
  prediction before its reveal.
- **Score-table rows**: `fixed_expert` stands for row 1 and `maestro_core` for row 5.
  Rows 2, 3, 4 and 6 have no offline arm and are reported `not_run` with their reasons.

## Exit rule for the declared `prediction_value` input (section 29)

Informed arm `prediction_value_heuristic`; controls `prediction_value_removed` (all values
read as zero) and `prediction_value_shuffled` (a seeded derangement, seed 20260914, over
each case's available actions); declaration reader `outcome_aware_selection`.

1. `remove_from_loop` triggers unless the informed arm has strictly fewer incorrect
   verdicts than both controls.
2. `demote_to_feature_provider` is not assessable: the input has no scored prediction
   quality. This is stated now, not discovered later.
3. `record_as_external_information_gain` triggers when condition 1 did not trigger and the
   declaration reader has no more incorrect verdicts than the informed arm.
4. `tighten_applicability_domain` is not assessable: the input declares no domain.

The consequence is the first triggered condition in this order, otherwise `retain`.

## Expectations, with their reasons

- **E1.** Every arm's laboratory cost on `real_v3` is 0 wells and 0 days, and every
  acquisition is a record retrieval, because the package README states that no action
  commissions an experiment and the only measurement is permanently unavailable.
- **E2.** The final-test verdict is `partition_absent` for every case: no package carries
  held-back results yet.
- **E3.** The table does not support a comparison, because rows 2, 3, 4 and 6 cannot run.
- **E4.** The shuffled and removed controls over-defer more than the informed arm on cases
  with three available actions, because the declared values place 0.6 or 0.7 on the
  actions whose declared outcomes separate the hypotheses and 0.3 or 0.4 on the others. If
  so, condition 1 does not trigger, and condition 3 is expected to trigger because the
  declaration reader reads that same separation directly.

## What had already been seen

- The 2026-09-12 record reports, on the original 60-case `real` package:
  `prediction_value_heuristic` 56/60 (four over-deferrals), `fixed_expert` 40/60,
  `maestro_core` 60/60, `repair_disabled` 40/60, `random_legal_edit` 43/60,
  `outcome_aware_selection` 60/60, and identical acquisition sequences for `maestro_core`
  and `outcome_aware_selection` in 60 of 60 cases.
- `Innovation.md` section 9.9 records the ablation reproduced on `real_v3` as 58/58, 43/58,
  44/58 and 58/58.
- Not seen before this file was written: any arm of the prediction panel on `real_v3`, any
  shuffled or removed control, and any laboratory-cost figure. The costing overlays were
  written after reading the package README and the action descriptions, before any cost
  total existed.

## What these runs cannot establish

No biological result, no target engagement and no mechanism. The declared prediction value
is a case author's score, not a model, so an exit verdict applies to that input only.
There is no adjudication blind to the arms' outputs, so no row of either table is evidence
for the core claim, and the table says so in its own `conclusion`.

## Addendum, 2026-09-14 20:10, appended before either registered run

After the text above was written, `tests/test_evaluation_protocol.py` executed the same eight
arms on the same two contract cases, into a temporary directory, and its table was read.
The contract run is therefore **not blind to its own outcome**: on those two cases every
arm had 0 wrong actions and deferred correctly on the one eligible case; `fixed_expert`,
`maestro_core`, `prediction_value_removed` and `prediction_value_shuffled` had 0
over-deferrals and spent 72 wells to reach the standard, while
`prediction_value_heuristic`, `outcome_aware_selection`, `repair_disabled` and
`random_legal_edit` had 1 over-deferral and 0 wells. Nothing from `real_v3` was seen, and
none of the definitions, expectations or the exit rule above were changed after that
reading.
