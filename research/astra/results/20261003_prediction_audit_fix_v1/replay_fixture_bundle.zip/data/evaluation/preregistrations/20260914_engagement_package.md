> **File summary**
> - **Path**: `data/evaluation/preregistrations/20260914_engagement_package.md`
> - **Purpose**: pre-registration of the MAESTRO engagement-repair case package: the
>   construction procedure, the qualified outcome rule, the licensing rules, the held-back
>   partition, the arms, the metrics, the blind adjudication and five falsifiable
>   expectations, all fixed before any hidden value or arm output for this package was read.
> - **Core points**: the engagement call is calibrated on the release's own vehicle channels
>   and its error is measured, not chosen; every purchasable action is a released-record
>   retrieval priced at 0 wells and 0 turnaround days; the repair is an agent proposal
>   compiled against a typed capability registry, not a case-author retyping.
> - **Interfaces / data**: `src/evaluation/engagement_sources.py`,
>   `src/evaluation/engagement_cases.py`, `src/evaluation/capabilities.py`,
>   `data/evaluation/cases/engagement_v1/`, `data/evaluation/capabilities/`.
> - **Depends on**: `data/evaluation/preregistrations/20260914_evaluation_protocol.md`,
>   `log/20260914/README.md`, `src/evaluation/case_builder.py`.

# Pre-registration: engagement-repair package (2026-09-14, late)

Written before the case builder was executed over any hidden value, before any arm ran on
this package, and before any adjudication was produced. Times are UTC.

## 1. Why this package exists

Gate G2 is FAIL: no hidden-result development case with a qualified outcome rule exists.
On the frozen `real_v3` package the certified value of a correctly typed repair is 0.000 in
58 of 58 cases because the menu is redundantly decisive, and the repair measured there is a
case-author retyping rather than the agent's own proposal. This package is built to expose
that claim to refutation on real records: the interpretation premise a decision needs is
missing from the menu, a typed capability registry can supply it, and the agent has to
identify the premise and propose the capability itself.

## 2. Disclosure of what was already seen

- **Read before selection (public premise, by design):** DepMap 24Q2 gene effect, RNA
  abundance and panel dependency fraction for the curated targets of the 96 compounds the
  engagement release assayed in cells, and the GDSC2 8.5 K-562 fitted curves (`LN_IC50`,
  `AUC`, `MAX_CONC`) of the 28 compounds that overlap. These values are the case premise and
  are public in every case file.
- **Not read:** any engagement value in the release (only column labels, protein
  identifiers and row counts), any kinobeads apparent-Kd value (only the column schema and
  the legend), any MCF7 phenotype value.
- **Seen indirectly, and therefore disclosed:** `.workbuddy/memory/MEMORY.md`, the notes of
  a concurrent session, read at 2026-09-14 20:40 UTC. It quotes outcomes from work blocks
  whose records the owner deleted earlier on 2026-09-14: engagement values and ranks for
  palbociclib, ribociclib and abemaciclib in K562 (a separate experiment in the same
  release), GDSC2 K-562 values for palbociclib and ribociclib, DepMap K562 gene effects for
  CDK4, CDK6, ABL1 and BCR, a Hill-2017 MCF7 AZD8055 phosphosite result, a Nyman-2020 A2058
  result, and the outcome of a SciPlex3 realisation ablation. Consequences, accepted rather
  than worked around: palbociclib, ribociclib and abemaciclib are excluded from this package
  (they are also absent from the 96-compound cell arm this package reads); the K562 gene
  effects of ABL1, BCR, CDK4 and CDK6 were known to the author before selection; and the
  realisation ablation of the separate direction-I work is a re-run of a deleted result that
  cannot be cited, so it is not blind.
- No number from those deleted blocks is cited as evidence anywhere in this work.

## 3. Sources, identity and provenance

| Role | Release | Local path | Identity |
|---|---|---|---|
| Engagement (hidden until acquired) | PISA living-cell arm, eLife 2024, DOI 10.7554/eLife.95595 | `data/external/pisa_living_cells/PMC11554310_supplementary.zip`, member `elife-95595-supp3.xlsx`, sheet `Cell-based data` | zip sha256 recorded in its provenance sidecar; 8,390 protein rows, 128 labels x 2 replicate channels, 32 vehicle groups, 96 compounds, living K562 cells |
| Phenotype (premise) | GDSC2 release 8.5 | `data/external/gdsc2_fitted/GDSC2_fitted_dose_response_27Oct23.xlsx` | sha256 in its provenance sidecar; K-562 = SIDM00791, MCF7 = SIDM00148 |
| Dependency and abundance (premise) | DepMap 24Q2 Public | `data/raw/depmap/{CRISPRGeneEffect.csv,OmicsExpressionProteinCodingGenesTPMLogp1.csv,Model.csv}` | MD5 verified by the existing provenance sidecars; K562 = ACH-000551, MCF7 = ACH-000019 |
| Second-context phenotype (premise) | PRISM Repurposing 19Q4 secondary screen | `data/raw/prism/secondary-screen-dose-response-curve-parameters.csv` | MD5 verified by its provenance sidecar |
| Independent binding test (always hidden) | Klaeger et al. 2017 kinobeads | `data/raw/kinobeads/Klaeger_allTargets.xlsx`, sheet `Kinobeads` | 5,916 rows; columns `Apparent Kd`, `Target Classification`, `Lysate` |

The engagement release's exposure concentration and duration are **not declared in the local
asset**. They are recorded as `undeclared_in_local_asset`, no condition match to the
multi-day viability assay is claimed, and the premise requirement declares no time window.

Compound identity across releases is matched on the folded name: lower case, punctuation
removed, parenthetical salt forms dropped. RDKit is absent and no local release carries a
structure key for every compound, so an unmatched name is reported as
`compound_identity_unmatched` and the pair is excluded rather than guessed.

## 4. The qualified outcome rule for engagement

Fixed here, before any value was read:

1. The effect of one label on one protein is the mean of that label's two `Log2FC` replicate
   channels.
2. The 32 vehicle groups are split by sorted position into a calibration half (every other
   group) and a hold-out half.
3. The call threshold is the 95th percentile of the absolute effects pooled over the
   calibration vehicle groups and every quantified protein. The 95 per cent level is
   inherited from the project's declared interval convention (`score_table.Z_95`, the Wilson
   and cluster-bootstrap intervals, the State receipts' drug bootstrap). It is not chosen for
   this package and is not tuned to any case count.
4. A pre-specified protein is called `engaged` when its absolute effect is at or above the
   threshold, and `not_engaged` otherwise.
5. The **measured** false-positive rate is the exceedance rate on the held-out vehicle half,
   reported with a one-sided 95 per cent Clopper-Pearson upper bound. That bound is this
   package's declared error budget for one pre-specified protein.
6. A protein the release did not quantify produces **no record**. The capability reports
   `entity_not_quantified_in_capability`; a missing value is never read as evidence of no
   engagement.
7. Sensitivity is not assumed. The annotation-recovery rate over the **development split
   only** - the fraction of (compound, curated target) pairs called engaged - is reported as
   a lower bound on sensitivity and is the only sensitivity figure used.

## 5. Case construction, blind to every hidden value

Selection reads the premise releases and the engagement release's own curated-target
annotation and coverage flags. It never reads an engagement value.

Calls inherited unchanged from `case_builder.ARCHETYPE_THRESHOLDS`: `strong_dependency`
-0.7, `absent_dependency` -0.2, `selective_gene_fraction` 0.30,
`pan_essential_gene_fraction` 0.90. The phenotype call is the release's own boundary: a
curve is `active` when its fitted IC50 (`exp(LN_IC50)`) is at or below the maximum screened
concentration, and `inactive` otherwise; `AUC` is recorded beside it and never overrides it.

| Archetype | Premise pattern | Competing explanations and their development actions |
|---|---|---|
| `engagement_gap_or_mode` | a curated target is a strong selective dependency and the compound is inactive | `insufficient_target_engagement` -> `revise_intervention`; `genetic_pharmacological_mode_non_equivalence` -> `change_intervention_mode` |
| `unattributed_active_compound` | the compound is active and no curated target reaches the absent-dependency boundary | `target_mediated_pharmacology` -> `continue`; `phenotype_not_target_attributable` -> `revise_attribution` |
| `concordant_support` | a curated target is a strong dependency and the compound is active | `target_mediated_pharmacology` -> `continue`; `phenotype_not_target_attributable` -> `revise_attribution` |
| `no_engagement_coverage` | a discordant premise whose curated targets are not quantified in the engagement release | as for `engagement_gap_or_mode`, with no admissible repair |
| `engagement_capability_out_of_context` | second context (MCF7), premise from PRISM and DepMap, no local in-context engagement release | as for `engagement_gap_or_mode`, with every engagement proposal refused by name |

At most four cases per archetype and one case per (primary target, archetype) pair, taken in
alphabetical compound order. Split by primary target gene using the repo's `assign_split`
parity rule over the package's gene set, so a gene never crosses splits. Inclusion is never
decided by any policy's performance; the screening table records every candidate and its
exclusion reason.

## 6. Menu, prices, budget and the missing premise

Every purchasable action retrieves an already released record: basis `record_retrieval`,
0 wells and 0 turnaround days. The one action priced as a new measurement is registered
unavailable.

| Action | Cost | Laboratory price | Role |
|---|---:|---|---|
| `target_abundance_rna` | 1.0 | 0 wells, 0 days | supplies `abundance:target_rna` |
| `dependency_selectivity_profile` | 1.0 | 0 wells, 0 days | supplies `attribution:dependency_selectivity` |
| `mode_matched_comparator` | 1.0 | 0 wells, 0 days | prerequisite `abundance:target_rna`; interpretation gate `engagement:comparator_on_target` |
| `matched_target_engagement` | 3.0 | 24 wells, 4 days | `available: false`: the condition-matched assay this package cannot serve |

Case budget 3.0. The premises no menu action supplies are `engagement:index_on_target`,
`engagement:comparator_on_target` and, in `unattributed_active_compound`,
`attribution:engaged_context_dependency`. Two routes therefore exist under the budget - buy
the index compound's engagement, or unlock the gated comparator by buying the comparator's
engagement - and they differ in price and in what they can conclude.

## 7. The capability registry and the repair operator

`data/evaluation/capabilities/engagement_capabilities_v1.json` publishes typed capability
offers with no values: the quantity, entity template, units, context, cost, laboratory
price, the premise field each supplies, the compounds and genes each covers, and the source
citation with its digest. A thermal-stability shift is typed `engagement_shift`: it is not
occupancy and not proximal activity, so it cannot discharge a premise that asks for either.

A policy may emit one proposal per case in the framework's own operator language:
`{"operator": "register_supplier", "capability": <id>, "supplies": <premise field>,
"entity": <gene>, "compound": <compound>}`. Compilation refuses by name:
`capability_not_registered`, `premise_not_missing`, `capability_does_not_supply_premise`,
`capability_does_not_cover_compound`, `entity_not_quantified_in_capability`, and the typed
admission reasons of the framework (`quantity_mismatch`, `context_mismatch`,
`units_mismatch`, `entity_mismatch`, `estimate_offered_for_direct_measurement`).

A compiled proposal becomes one new action `repair__<capability>__<compound>__<entity>`
whose hidden result is the pre-computed record; no policy can read it without acquiring it.
The outcome-to-hypothesis mapping is taken from the capability's declared template and the
case's hypothesis annotation, never from the proposal, so a model cannot invent an outcome
model. A proposal's own claimed mapping, cost and reliability are recorded and compared, and
are not used in scoring.

## 8. Arms

All arms see the same premise, menu, budget, premise registry and capability registry.

1. `fixed_expert` - the repo's fixed-order menu baseline.
2. `outcome_aware_selection` - the strongest one-shot menu selector.
3. `maestro_core` - the repo's check-and-repair loop over the menu.
4. `registry_repair_rule` - the repair operator extended to the registry: read the named
   missing premise from the contrast check, propose the cheapest typed-admissible capability.
5. `registry_expanded_selection` - control: every compilable capability action is added to
   the menu in advance and the one-shot selector runs. If this matches arm 4, the credit
   belongs to the registry's content and not to the proposal step.
6. `registry_repair_random` - control: a seeded random capability proposal, so typed
   admission is what filters it.
7. `registry_repair_llm` - the configured model proposes one repair per case in the same
   operator language. Paid; spend is reported separately in USD and tokens.
8. `retrieval_single_agent` (section 37 row 3) and `same_llm_explicit_hypotheses` (row 4).
9. `simple_model_plus_voi` (row 2) - an outcome model fitted on the development split plus
   exact value-of-information planning.
10. `full_system_shuffled_predictions` (row 6) - arm 4 with its prediction input replaced by
    a seeded derangement.

## 9. Metrics, certificates and the blind adjudication

- Primary metric: the wrong-development-action rate per arm, split into wrong advance,
  premature abandonment and wrong direction, with over-deferral and appropriate deferral
  counted separately. The statistical unit is the case; the cluster is the primary target
  gene; intervals are Wilson and a seeded cluster bootstrap.
- Cost is reported in wells and turnaround days only. Provider spend is reported separately
  and never enters a cost comparison.
- The certified value of a repair is the admissible-objective certificate - the menu-only
  optimum minus the optimum with the compiled proposal - reported under **both** licence
  readings: the recorded exclusion tolerance 1e-9, and the measured engagement error budget
  of section 4. Neither reading is reported alone.
- Blind adjudication, both adjudicators fixed before any arm runs on this package:
  (a) the mechanical adjudicator is the licensing rule set of section 5, hashed into the
  private case files; (b) the independent reviewer is the configured model in a fresh
  context, given a packet containing the premise, the hypotheses and every hidden record,
  and asked for the acceptable decisions and the minimum evidence. It never sees an arm
  output and it constructed no case. Agreement is reported as raw agreement and Cohen's
  kappa with the per-case disagreement list; disputed cases are scored separately and are
  never merged into the headline rate.

## 10. Pre-registered expectations

- **E1** Laboratory cost is 0 wells and 0 turnaround days for every arm, because every
  purchasable action is a retrieval and the only priced new measurement is unavailable.
- **E2** `registry_repair_rule` reaches a licensed non-deferral decision in at least one
  `engagement_gap_or_mode` case where `outcome_aware_selection` defers.
- **E3** The certified value of the compiled proposal is strictly positive under the
  measured error budget in at least one case, and is exactly 0.000 for
  `registry_repair_random` in every case.
- **E4** Under the recorded exclusion tolerance 1e-9 and a measured error model, the
  certified value is 0.000 in every case: a noisy measurement cannot exclude a hypothesis
  outright, and that is a structural property of the tolerance rather than of the repair.
- **E5** The held-back kinobeads partition contradicts at least one arm's decision in at
  least one case. Where no kinobeads record covers a case, the partition is reported as
  `partition_absent` for it.

## 10a. Addendum, 2026-09-14 21:15 UTC: one corrected rule, three fixed conventions

Written after the screening pass ran over the **premise** releases and before any hidden
value was read into a case file, before any arm ran, and before any adjudication existed.
The screening output that prompted it is `data/evaluation/derived/engagement_screening_v1.json`.

**What the registered rule produced.** Section 5 requires, for `engagement_gap_or_mode`, that
a curated target be a **strong selective** dependency. Applied to the 96 compounds the
engagement release assayed in cells, it yields **zero** cases in that archetype and two in
`concordant_support`: every K562 compound that is inactive against a strong dependency has a
**pan-essential** target (CDK1 fraction 1.000, ATR 0.990, MTOR 0.985, BRD4 0.947). The
archetype that carries the entire repair claim would have been empty.

**The one correction.** The selectivity requirement is dropped from `engagement_gap_or_mode`
only. The substantive reason, and not the case count, is that the question this archetype
asks - did the compound engage the target in this context, or did engagement not reproduce
genetic loss - does not depend on how many other cell lines need that gene. Panel-wide
essentiality is a statement about the target's distribution, not about this compound's
realisation, and it is recorded as a limitation on every case it applies to. The superseded
rule stands above in section 5 and is not edited away. Every other threshold is unchanged.

**What is deliberately not corrected.** `unattributed_active_compound` (all curated targets
above the absent-dependency boundary, an active compound and an unexpressed target) has
**zero** instances in K562, and `no_engagement_coverage` has zero, because the compounds
whose targets the release does not quantify are not inactive against a strong dependency.
Moving the absent-dependency boundary from -0.2 to the release-level -0.5 would admit two
compounds, and it is not moved: that would be a threshold chosen to fill a case type. The
consequence is recorded rather than worked around - the package covers three of the four G2
case types, so **G2 coverage is not met** and this package cannot close G2 on its own.

**Three conventions fixed here, before any run.**

1. *Always-hidden partition mapping.* For an engagement-question archetype, a kinobeads
   record that lists the primary target with a finite apparent Kd confirms
   `change_intervention_mode`; a compound whose kinobeads profile does not list that target
   confirms `revise_intervention` and contradicts `change_intervention_mode`. For
   `concordant_support`, listed confirms `continue`, not listed confirms `revise_attribution`
   and contradicts `continue`. Every record carries the limitation that competition binding
   in a foreign lysate does not establish engagement in cells.
2. *Over-deferral.* The verdict is reported twice: against menu-only reachability, the
   convention the frozen packages use, and against registry-extended reachability, in which a
   decision licensable through a compilable capability counts as reachable. Neither is
   reported alone, and the headline table names which one it uses.
3. *Premise subject typing.* An engagement premise is about one gene **under one compound**,
   so the typed entity is `GENE@foldedcompound`. A proposal that measures the right gene
   under the wrong compound is refused by the framework's own entity check.

## 11. What this package cannot establish

No new experiment is performed. The engagement, phenotype, dependency and binding records
come from four different releases and are not matched for exposure, dose, duration, assay or
replicate structure. A thermal-stability shift is an engagement effect size, not an occupancy
fraction, and the release's exposure conditions are undeclared locally. The licensing rules
are an evidence-sufficiency convention declared in advance, not biological ground truth, and
a policy may legitimately disagree with them. The second adjudicator is a language model
rather than a human domain reviewer, so the scientific part of gate G2 remains INCONCLUSIVE
until a human review is recorded, however the engineering part of G2 turns out.
