> **File summary**
> - **Path**: `data/evaluation/SCORING_CONTRACT.md`      (real relative path)
> - **Purpose**: defines the G0 terminal-submission and scoring contract.
> - **Core points**:
>   - State virtual-cell module is disabled for this stage.
>   - Five required submission fields are specified.
>   - One format-only retry is allowed; no correct answer is leaked.
> - **Interfaces / data**: `g0-v1`, `decision`, `evidence_ids`, `needs_more_evidence`
> - **Depends on**: `data/evaluation/README.md`, `INNOVATION_VALIDATION_GATES.md`

# G0 Scoring Contract

Version `g0-v1` defines the development replay contract before policy comparison. The State virtual-cell module is disabled for this stage (gate G0).

Every policy receives the same public case data, registered hypotheses, action menu, budget, execution checks, and only previously revealed outcomes. Private result text, critical actions, and decision rules remain evaluator-owned. A decision submission has five required fields: `decision`, `evidence_ids`, `rationale`, `limitations`, and `needs_more_evidence`.

A terminal submission requires a registered decision, one or more previously revealed evidence identifiers, nonempty rationale, string limitations, and a boolean `needs_more_evidence: false`. A nonterminal request must use `needs_more_evidence: true`, omit a terminal decision, and cite no terminal evidence. The evaluator allows at most one format-only retry. The retry reports only schema or revealed-evidence-reference errors; it does not expose a correct action or private outcome. Both attempts count as provider calls and tokens.

Scoring separately reports supported decisions, supported autonomous decisions, fallback decisions, and invalid submissions. A supported autonomous decision must have `origin: agent`, a valid submission, cited revealed evidence, and match a private rule. `fallback` is never counted as autonomous success. A correct-looking action without the minimum revealed evidence is unsupported. Qualified evidence can support more than one registered action when the private contract defines multiple rules. No outcome is manufactured for unavailable actions or failed quality control.

The existing synthetic case is a contract test only. The SNU761/PRISM case is a real partial boundary control. Neither establishes a directed-repair benefit. G4/G5 require the separately frozen development and holdout case registries described in `INNOVATION_VALIDATION_GATES.md`.
