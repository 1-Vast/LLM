> **File summary**
> - **Path**: `data/evaluation/README.md`      (real relative path)
> - **Purpose**: explains the frozen replay cases, modes, runs, and policies.
> - **Core points**:
>   - `cases/public/` is visible; `cases/private/` holds outcomes and scoring.
>   - `cases/real/` is the generated 60-case licensing benchmark built from public releases.
>   - `regression` checks wiring; `decision` scores a submitted policy.
>   - SNU761/PRISM is a real partial boundary case, not a G2 pass.
> - **Interfaces / data**: `maestro-evaluate.exe`, `candidate_registry.json`, `SCORING_CONTRACT.md`
> - **Depends on**: `data/evaluation/SCORING_CONTRACT.md`

# Replay Evaluation Cases

`cases/public/` holds the frozen material visible to a policy: initial evidence, registered hypotheses, a costed action menu, conditions, source references, and limitations. It holds neither outcome text nor scoring answers. The case belongs to one source cluster. `cases/private/` holds outcome records and evaluator-only scoring rules. A policy receives `ReplayView`, which exposes only public material plus outcomes already released by a selected query.

Private result records separate source-record validation from biological quality, conditions from fitted metrics, record count from known biological replicates, and retrieved/derived/measurement evidence kinds. A source curve is not upgraded into a new physical measurement merely because it is imported.

`synthetic-functional-calibration-001` is a contract/regression case. `depmap-prism-snu761-egfr-osimertinib-001` is a real-data partial evidence boundary case. Its PRISM record is valid only for its narrow retrieval claim; the case cannot establish condition-matched target engagement or mechanism.

`cases/real/` is a separate, generated package: 60 leakage-bounded cases built from the local DepMap 24Q2 and PRISM Repurposing 19Q4 releases by `maestro-build-cases`, spread over six joint evidence patterns and split by target gene. Its private files hold evidence-licensing rules rather than a single expected answer, and its boundary is documented in [`cases/real/README.md`](cases/real/README.md). The two cases above stay in `cases/public` and `cases/private` as the contract and boundary controls; point `--public-cases` and `--private-results` at the real package to evaluate against it.

## Modes

`regression` verifies evidence acquisition and bounded main-loop wiring. Its terminal result has `decision_origin: rule`; it is not an independent policy decision evaluation.

`decision` requires a policy submission containing a decision, revealed evidence identifiers, rationale, limitations, and whether it needs more evidence. The evaluator privately scores that submission; it never replaces an incorrect policy decision with the expected answer.

## Runs

Every invocation creates `evaluations/runs/<run_id>/` under the active `--output` directory. Each `run_id/policy/case_id` has isolated, leakage-bounded memory, evidence, logs, and a `CaseStore` SQLite ledger. A new invocation always starts fresh. Resume only with an explicit existing `--run-id --resume`; it restores revealed actions and budget from that ledger without another query or charge.

The default `all` policy is offline: fixed workflow, declared-score heuristic, and deterministic MAESTRO core. It never calls an LLM. `ordinary_llm` and `maestro_llm` are explicit provider-backed modes and record safe model/usage metadata without storing keys, prompts, or private unrevealed outcomes.

```powershell
D:\anaconda\envs\maestro\Scripts\maestro-evaluate.exe --policy all --run-id offline-20260910
D:\anaconda\envs\maestro\Scripts\maestro-evaluate.exe --policy all --mode decision --run-id decision-20260910
D:\anaconda\envs\maestro\Scripts\maestro-evaluate.exe --policy maestro_llm --case-id depmap-prism-snu761-egfr-osimertinib-001 --run-id llm-real-20260910
D:\anaconda\envs\maestro\Scripts\maestro-evaluate.exe --policy maestro --run-id resume-example --maximum-steps 1
D:\anaconda\envs\maestro\Scripts\maestro-evaluate.exe --policy maestro --run-id resume-example --resume
```

New public cases use `templates/real_case.template.json`; their private result and scoring contract use `templates/real_case.results.template.json`.

## Laboratory cost, refusals and the hidden partition

The abstract `cost` stays the budget unit, and a laboratory price sits beside it. An action's price is a `lab_cost` object (`basis`: `new_measurement` or `record_retrieval`; `wells`; `turnaround_days`; optional `shared_control` and `reagent_burden`), given inline in a public case or in an overlay under `costing/` that leaves the frozen packages untouched. A retrieval consumes no wells and no days. A shared control's wells are charged once per executed sequence. An executed action with no price makes that case's laboratory cost `lab_cost_undeclared:<ids>`, never zero. `costing/real_record_retrieval.json` prices the three real packages, where every executable action retrieves a released record. `costing/contract_and_boundary_cases.json` prices the two cases above with the governing report's section 36 illustrative menu.

A refused query raises `RevealRefusal`, whose `code` names the reason; its message is unchanged.

A private file may add `final_test`: records no policy can query, each listing the development actions it would `confirm` or `contradict`. They never enter the replay environment. A record that shares an identifier with a menu action or a revealable result is refused. The resulting `final_test_verdict` is reported beside the licensing verdict and never changes it; a package without the list reports `partition_absent`.

## Protocol runs and the score table

`--policy protocol` runs eight offline arms: the section 9.3 ablations plus the prediction panel (`prediction_value_heuristic`, `prediction_value_shuffled`, `prediction_value_removed`). `--score-table` writes the governing report's section 37 table beside the evaluation JSON. It has six fixed rows, `not_run` with a reason where no arm implements a row, and a section 29 exit verdict for the declared prediction input. `--preregistration` records a pre-registration's digest and refuses one modified after the run began; pre-registrations live under `preregistrations/`. `--state-root` keeps the per-case ledgers out of the report directory.

```powershell
D:\anaconda\envs\maestro\python.exe -m evaluation.cli --public-cases data/evaluation/cases/real_v3/public --private-results data/evaluation/cases/real_v3/private --mode decision --policy protocol --costing data/evaluation/costing/real_record_retrieval.json --manifest data/evaluation/derived/real_case_manifest_v3.json --state-root tmp/evaluation_state --score-table --run-id protocol-example
```

`SCORING_CONTRACT.md` is the G0 terminal-submission and scoring specification. `candidate_registry.json` is a source-screening ledger, not a policy-visible replay case. Validate it with `maestro-screen-cases`; a candidate marked ineligible must not be copied into the development evaluation set. The current SNU761/PRISM entry is intentionally retained as an incomplete real boundary control (a deferral of a full case) and does not satisfy G2.

## The engagement-repair package and its capability registry

`cases/engagement_v1/` is the first MAESTRO package in which the premise a decision needs is **not
on the menu**. Each case states a genetic-versus-pharmacological discordance from released records
- a CRISPR dependency, a fitted phenotype curve, a curated target annotation - and the menu can buy
only retrievals that cannot settle it. The missing premise is whether the compound engages its
annotated target in that context.

`capabilities/engagement_capabilities_v1.json` (`maestro.capabilities.v1`) publishes what each
local release *could* supply: the quantity, entity, units, context, price and coverage, and no
value. A policy may emit one proposal per case in the framework's own operator language, and the
framework compiles it or refuses it by name (`capability_not_registered`, `premise_not_missing`,
`capability_does_not_cover_compound`, `entity_not_quantified_in_capability`, plus the typed
admission reasons). A compiled proposal becomes one action whose hidden result the policy must
still buy. A cell-lysate binding offer is registered deliberately so that proposing it is answered
with `quantity_mismatch` rather than with silence.

The engagement call is calibrated on the release's own vehicle channels rather than chosen: the
threshold is the 95th percentile of vehicle-versus-vehicle absolute effects on a calibration half
of the vehicle groups, and the held-out half gives the measured false-positive rate with a
one-sided 95 per cent bound. Both numbers are written into every case file. The sensitivity is
reported separately as an annotation-recovery rate on development-split compounds, because a
negative call is the weaker half of this assay.

Four cases also carry an always-hidden partition: an independent competition-binding record that no
policy can query and that the framework refuses as an engagement supplier, so it can only test a
decision already made.

```text
maestro-evaluate --public-cases data/evaluation/cases/engagement_v1/public \
  --private-results data/evaluation/cases/engagement_v1/private \
  --capabilities data/evaluation/capabilities/engagement_capabilities_v1.json \
  --manifest data/evaluation/derived/engagement_case_manifest_v1.json \
  --mode decision --policy repair --run-id <new-run-id>
```

`--policy repair` runs six offline arms: three that cannot propose at all, the directed proposal,
the catalogue-expansion control and a seeded random proposal. Every result carries two verdicts -
against the frozen menu and against what the registry makes reachable for any arm - and neither is
reported alone. `src/evaluation/repair_certificate.py` prices the same repair as a bound on every
menu-restricted policy, under the recorded exclusion tolerance and under the package's own measured
call error.

## The section 37 rows, and the arms that stand for them

The table's six rows are fixed and named in `src/evaluation/score_table.py`. A row with no
evaluated arm stays `not_run` **with its reason**; an arm is never assigned to a row merely
because it exists, which is why the row-to-arm mapping is declared per run with `--row-arms`
rather than inferred.

| Row | Arm | Where it lives |
|---|---|---|
| 1 fixed expert rule flow | `fixed_expert` | `baselines.py` |
| 2 simple response model with EIG/VOI | `simple_model_voi` | `voi_arm.py` |
| 3 retrieval-based single agent | `ordinary_llm` | `baselines.py`, provider-backed |
| 4 same LLM, explicit hypotheses | `explicit_hypotheses_llm` | `llm_rows.py`, provider-backed |
| 5 full system | `maestro_core` | `baselines.py` |
| 6 full system, shuffled predictions | `maestro_core_shuffled_predictions` | `prediction_controls.py` |

`--policy rows` runs the four offline rows together and never makes a paid call; the two
provider-backed rows are named explicitly. Row 2 fits its outcome model on the development split
declared in the manifest - each action's reliability, meaning how often its record carried an
outcome the case declared for one of its explanations - and is refused rather than run unfitted.
Row 6 deranges the prediction input the full system reads; where that arm is identical to row 5,
the reading is that the input is not in the loop, never that the input was harmless.

## The blind adjudication

`src/evaluation/adjudication.py` produces, for every case, the development actions the evidence
supports, from two adjudicators fixed before any arm output is compared to them: the package's own
frozen licensing rules evaluated with every record revealed, and an independent reviewer given an
adjudication packet and nothing else. The packet carries the premise, the registered explanations,
the menu's declarations and every hidden record the case holds, including the always-hidden
partition; it carries no licensing rule, no policy name and no decision, so a reviewer cannot
recognise a strategy's answer.

```text
D:/anaconda/envs/maestro/python.exe src/evaluation/adjudication.py \
  --public-cases data/evaluation/cases/real_v3/public \
  --private-results data/evaluation/cases/real_v3/private \
  --workspace . --output evaluations/runs/<run-id>
```

Agreement is reported as raw agreement on the supported set, Cohen's kappa over per-case
per-action binary judgements, and the full disagreement list with both verdicts quoted. A case
where the two adjudicators disagree is **disputed** and is reported separately rather than merged
into a headline rate. The reviewer is a language model in a fresh context, not a human domain
reviewer, and it shares a model family with two of the evaluated arms; both limitations are
carried in the output beside every agreement figure.

Paid calls are priced by `src/evaluation/provider_spend.py` from the provider's own usage fields,
reserved before the call and charged after it, with a failure that occurred after token processing
charged at its reservation rather than at zero. The ledger enforces the authorised ceiling by name
and carries a declared prior total, so a run states what campaign spend it inherited.
